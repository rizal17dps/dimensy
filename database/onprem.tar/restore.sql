--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE contract_management;
--
-- Name: contract_management; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE contract_management WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE contract_management OWNER TO postgres;

\connect contract_management

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: account_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_payment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_payment_id_seq OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_payment (
    id integer DEFAULT nextval('public.account_payment_id_seq'::regclass) NOT NULL,
    move_id integer NOT NULL,
    is_reconciled boolean,
    is_matched boolean,
    partner_bank_id integer,
    is_internal_transfer boolean,
    payment_method_id integer,
    amount numeric NOT NULL,
    payment_type character varying NOT NULL,
    partner_type character varying NOT NULL,
    payment_reference character varying,
    currency_id integer NOT NULL,
    partner_id integer,
    destination_account_id integer,
    message_main_attachment_id integer,
    create_uid integer,
    create_date timestamp without time zone,
    write_uid integer,
    write_date timestamp without time zone,
    payment_transaction_id integer,
    payment_token_id integer,
    name character varying,
    state character varying,
    journal_id integer NOT NULL,
    payment_date date NOT NULL,
    is_deposit boolean,
    is_deposit_return boolean,
    deposit_payment_id integer,
    account_id integer,
    writeoff_account_id integer,
    partner_name character varying,
    account_code character varying,
    writeoff_account_code character varying,
    deposit_status character varying,
    move_name character varying,
    CONSTRAINT account_payment_check_amount_not_negative CHECK ((amount >= 0.0))
);


ALTER TABLE public.account_payment OWNER TO postgres;

--
-- Name: TABLE account_payment; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.account_payment IS 'Payments';


--
-- Name: COLUMN account_payment.move_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.move_id IS 'Journal Entry';


--
-- Name: COLUMN account_payment.is_reconciled; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.is_reconciled IS 'Is Reconciled';


--
-- Name: COLUMN account_payment.is_matched; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.is_matched IS 'Is Matched With a Bank Statement';


--
-- Name: COLUMN account_payment.partner_bank_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.partner_bank_id IS 'Recipient Bank Account';


--
-- Name: COLUMN account_payment.is_internal_transfer; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.is_internal_transfer IS 'Is Internal Transfer';


--
-- Name: COLUMN account_payment.payment_method_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.payment_method_id IS 'Payment Method';


--
-- Name: COLUMN account_payment.amount; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.amount IS 'Amount';


--
-- Name: COLUMN account_payment.payment_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.payment_type IS 'Payment Type';


--
-- Name: COLUMN account_payment.partner_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.partner_type IS 'Partner Type';


--
-- Name: COLUMN account_payment.payment_reference; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.payment_reference IS 'Payment Reference';


--
-- Name: COLUMN account_payment.currency_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.currency_id IS 'Currency';


--
-- Name: COLUMN account_payment.partner_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.partner_id IS 'Customer/Vendor';


--
-- Name: COLUMN account_payment.destination_account_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.destination_account_id IS 'Destination Account';


--
-- Name: COLUMN account_payment.message_main_attachment_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.message_main_attachment_id IS 'Main Attachment';


--
-- Name: COLUMN account_payment.create_uid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.create_uid IS 'Created by';


--
-- Name: COLUMN account_payment.create_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.create_date IS 'Created on';


--
-- Name: COLUMN account_payment.write_uid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.write_uid IS 'Last Updated by';


--
-- Name: COLUMN account_payment.write_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.write_date IS 'Last Updated on';


--
-- Name: COLUMN account_payment.payment_transaction_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.payment_transaction_id IS 'Payment Transaction';


--
-- Name: COLUMN account_payment.payment_token_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.payment_token_id IS 'Saved payment token';


--
-- Name: COLUMN account_payment.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.name IS 'Name';


--
-- Name: COLUMN account_payment.state; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.state IS 'Status';


--
-- Name: COLUMN account_payment.journal_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.journal_id IS 'Journal';


--
-- Name: COLUMN account_payment.payment_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.payment_date IS 'Payment Date';


--
-- Name: COLUMN account_payment.is_deposit; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.is_deposit IS 'Is Deposit?';


--
-- Name: COLUMN account_payment.is_deposit_return; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.is_deposit_return IS 'Return Payment?';


--
-- Name: COLUMN account_payment.deposit_payment_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.deposit_payment_id IS 'Deposit Payment Reference';


--
-- Name: COLUMN account_payment.account_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.account_id IS 'Account';


--
-- Name: COLUMN account_payment.writeoff_account_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.writeoff_account_id IS 'Difference Account';


--
-- Name: COLUMN account_payment.partner_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.partner_name IS 'Partner Name';


--
-- Name: COLUMN account_payment.account_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.account_code IS 'Account Code';


--
-- Name: COLUMN account_payment.writeoff_account_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.writeoff_account_code IS 'Writeoff Account Code';


--
-- Name: COLUMN account_payment.deposit_status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.deposit_status IS 'Deposit Status';


--
-- Name: COLUMN account_payment.move_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_payment.move_name IS 'Journal Entry Name';


--
-- Name: CONSTRAINT account_payment_check_amount_not_negative ON account_payment; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT account_payment_check_amount_not_negative ON public.account_payment IS 'CHECK(amount >= 0.0)';


--
-- Name: auth_client_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_client_id_seq OWNER TO postgres;

--
-- Name: auth_client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_client (
    id bigint DEFAULT nextval('public.auth_client_id_seq'::regclass) NOT NULL,
    company_id integer NOT NULL,
    token_name character varying(255) NOT NULL,
    token character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.auth_client OWNER TO postgres;

--
-- Name: brute_force; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.brute_force (
    id bigint NOT NULL,
    ip_address character varying(255),
    token character varying(255),
    email character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.brute_force OWNER TO postgres;

--
-- Name: brute_force_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.brute_force_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.brute_force_id_seq OWNER TO postgres;

--
-- Name: brute_force_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.brute_force_id_seq OWNED BY public.brute_force.id;


--
-- Name: company; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    alamat text,
    email character varying(255),
    tlp character varying(255),
    res_partner_id text,
    company_type character varying(255),
    type character varying(255),
    parent integer,
    logo text,
    slug character varying(255),
    payment_method character varying,
    isenterprise integer,
    lama character varying DEFAULT '1 Tahun'::character varying,
    status integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.company OWNER TO postgres;

--
-- Name: company_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.company_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_id_seq OWNER TO postgres;

--
-- Name: company_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.company_id_seq OWNED BY public.company.id;


--
-- Name: department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.department (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    company_id integer,
    status integer
);


ALTER TABLE public.department OWNER TO postgres;

--
-- Name: department_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.department_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.department_id_seq OWNER TO postgres;

--
-- Name: department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.department_id_seq OWNED BY public.department.id;


--
-- Name: detail_name; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detail_name (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    type character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.detail_name OWNER TO postgres;

--
-- Name: detail_name_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.detail_name_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.detail_name_id_seq OWNER TO postgres;

--
-- Name: detail_name_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.detail_name_id_seq OWNED BY public.detail_name.id;


--
-- Name: dok_base64; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dok_base64 (
    id bigint NOT NULL,
    dokumen_id integer NOT NULL,
    "base64Doc" text NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    "desc" text
);


ALTER TABLE public.dok_base64 OWNER TO postgres;

--
-- Name: dok_base64_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dok_base64_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dok_base64_id_seq OWNER TO postgres;

--
-- Name: dok_base64_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dok_base64_id_seq OWNED BY public.dok_base64.id;


--
-- Name: dok_sign; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dok_sign (
    id bigint NOT NULL,
    dokumen_id integer NOT NULL,
    "orderId" integer NOT NULL,
    name character varying(255),
    status character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    "parallelId" character varying(255),
    users_id bigint
);


ALTER TABLE public.dok_sign OWNER TO postgres;

--
-- Name: dok_sign_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dok_sign_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dok_sign_id_seq OWNER TO postgres;

--
-- Name: dok_sign_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dok_sign_id_seq OWNED BY public.dok_sign.id;


--
-- Name: dokumen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dokumen (
    id bigint NOT NULL,
    users_id integer NOT NULL,
    name character varying(255) NOT NULL,
    realname character varying(255) NOT NULL,
    status_id integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    tipe integer,
    step integer,
    id_bulk character varying
);


ALTER TABLE public.dokumen OWNER TO postgres;

--
-- Name: dokumen_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dokumen_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dokumen_id_seq OWNER TO postgres;

--
-- Name: dokumen_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dokumen_id_seq OWNED BY public.dokumen.id;


--
-- Name: email_template; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_template (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    content text NOT NULL,
    name character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    company_id integer,
    status integer,
    type character varying(255),
    logo_header text
);


ALTER TABLE public.email_template OWNER TO postgres;

--
-- Name: email_template_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.email_template_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.email_template_id_seq OWNER TO postgres;

--
-- Name: email_template_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.email_template_id_seq OWNED BY public.email_template.id;


--
-- Name: example; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.example (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status_id integer NOT NULL
);


ALTER TABLE public.example OWNER TO postgres;

--
-- Name: example_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.example_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.example_id_seq OWNER TO postgres;

--
-- Name: example_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.example_id_seq OWNED BY public.example.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: folder; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.folder (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    name character varying(255) NOT NULL,
    folder_id integer,
    resource boolean
);


ALTER TABLE public.folder OWNER TO postgres;

--
-- Name: folder_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.folder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.folder_id_seq OWNER TO postgres;

--
-- Name: folder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.folder_id_seq OWNED BY public.folder.id;


--
-- Name: form; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.form (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    name character varying(255) NOT NULL,
    table_name character varying(255) NOT NULL,
    read boolean NOT NULL,
    edit boolean NOT NULL,
    add boolean NOT NULL,
    delete boolean NOT NULL,
    pagination integer NOT NULL
);


ALTER TABLE public.form OWNER TO postgres;

--
-- Name: form_field; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.form_field (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    name character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    browse boolean NOT NULL,
    read boolean NOT NULL,
    edit boolean NOT NULL,
    add boolean NOT NULL,
    relation_table character varying(255),
    relation_column character varying(255),
    form_id integer NOT NULL,
    column_name character varying(255) NOT NULL
);


ALTER TABLE public.form_field OWNER TO postgres;

--
-- Name: form_field_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.form_field_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.form_field_id_seq OWNER TO postgres;

--
-- Name: form_field_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.form_field_id_seq OWNED BY public.form_field.id;


--
-- Name: form_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.form_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.form_id_seq OWNER TO postgres;

--
-- Name: form_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.form_id_seq OWNED BY public.form.id;


--
-- Name: history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.history (
    id bigint NOT NULL,
    dokumen_id integer NOT NULL,
    users_id integer NOT NULL,
    description character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.history OWNER TO postgres;

--
-- Name: history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.history_id_seq OWNER TO postgres;

--
-- Name: history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.history_id_seq OWNED BY public.history.id;


--
-- Name: history_pemakaian; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.history_pemakaian (
    id bigint NOT NULL,
    users_id integer NOT NULL,
    paket_detail_id integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    description character varying(255)
);


ALTER TABLE public.history_pemakaian OWNER TO postgres;

--
-- Name: history_pemakaian_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.history_pemakaian_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.history_pemakaian_id_seq OWNER TO postgres;

--
-- Name: history_pemakaian_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.history_pemakaian_id_seq OWNED BY public.history_pemakaian.id;


--
-- Name: history_transaksi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.history_transaksi (
    id bigint NOT NULL,
    company_id integer NOT NULL,
    paket_id integer NOT NULL,
    description character varying(255) NOT NULL,
    type integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.history_transaksi OWNER TO postgres;

--
-- Name: history_transaksi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.history_transaksi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.history_transaksi_id_seq OWNER TO postgres;

--
-- Name: history_transaksi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.history_transaksi_id_seq OWNED BY public.history_transaksi.id;


--
-- Name: industry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.industry (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    company_id integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.industry OWNER TO postgres;

--
-- Name: industry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.industry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.industry_id_seq OWNER TO postgres;

--
-- Name: industry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.industry_id_seq OWNED BY public.industry.id;


--
-- Name: jenis_dokumen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jenis_dokumen (
    id character varying(255) NOT NULL,
    nama character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.jenis_dokumen OWNER TO postgres;

--
-- Name: link_regis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.link_regis (
    id bigint NOT NULL,
    company_id integer NOT NULL,
    param character varying(255) NOT NULL,
    expired character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.link_regis OWNER TO postgres;

--
-- Name: link_regis_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.link_regis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.link_regis_id_seq OWNER TO postgres;

--
-- Name: link_regis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.link_regis_id_seq OWNED BY public.link_regis.id;


--
-- Name: list_signer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.list_signer (
    id bigint NOT NULL,
    users_id integer,
    step integer,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    dokumen_id integer NOT NULL,
    page integer,
    x1 character varying(255),
    x2 character varying(255),
    y1 character varying(255),
    y2 character varying(255),
    lower_left_x character varying(255),
    lower_left_y character varying(255),
    upper_right_x character varying(255),
    upper_right_y character varying(255),
    "isSign" integer,
    email character varying(255),
    reason character varying(255),
    location character varying(255)
);


ALTER TABLE public.list_signer OWNER TO postgres;

--
-- Name: list_signer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.list_signer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.list_signer_id_seq OWNER TO postgres;

--
-- Name: list_signer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.list_signer_id_seq OWNED BY public.list_signer.id;


--
-- Name: log_error; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.log_error (
    id bigint NOT NULL,
    ip character varying(255) NOT NULL,
    users_id character varying(255) NOT NULL,
    url character varying(255) NOT NULL,
    param text NOT NULL,
    "desc" text NOT NULL,
    status character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.log_error OWNER TO postgres;

--
-- Name: log_error_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.log_error_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.log_error_id_seq OWNER TO postgres;

--
-- Name: log_error_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.log_error_id_seq OWNED BY public.log_error.id;


--
-- Name: map_approver; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.map_approver (
    id bigint NOT NULL,
    users_id integer NOT NULL,
    profile_id integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.map_approver OWNER TO postgres;

--
-- Name: map_approver_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.map_approver_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.map_approver_id_seq OWNER TO postgres;

--
-- Name: map_approver_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.map_approver_id_seq OWNED BY public.map_approver.id;


--
-- Name: map_company; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.map_company (
    id bigint NOT NULL,
    paket_id integer NOT NULL,
    company_id integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    expired_date date
);


ALTER TABLE public.map_company OWNER TO postgres;

--
-- Name: map_company_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.map_company_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.map_company_id_seq OWNER TO postgres;

--
-- Name: map_company_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.map_company_id_seq OWNED BY public.map_company.id;


--
-- Name: map_paket_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.map_paket_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.map_paket_id_seq OWNER TO postgres;

--
-- Name: map_paket; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.map_paket (
    id bigint DEFAULT nextval('public.map_paket_id_seq'::regclass) NOT NULL,
    paket_id integer NOT NULL,
    paket_detial_id integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.map_paket OWNER TO postgres;

--
-- Name: map_pricing; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.map_pricing (
    id bigint NOT NULL,
    company_id integer NOT NULL,
    name_id integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    price integer NOT NULL,
    qty integer
);


ALTER TABLE public.map_pricing OWNER TO postgres;

--
-- Name: map_pricing_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.map_pricing_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.map_pricing_id_seq OWNER TO postgres;

--
-- Name: map_pricing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.map_pricing_id_seq OWNED BY public.map_pricing.id;


--
-- Name: media; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media (
    id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL,
    collection_name character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    file_name character varying(255) NOT NULL,
    mime_type character varying(255),
    disk character varying(255) NOT NULL,
    conversions_disk character varying(255) NOT NULL,
    size bigint NOT NULL,
    uuid bigint NOT NULL,
    manipulations json NOT NULL,
    custom_properties json NOT NULL,
    responsive_images json NOT NULL,
    order_column integer,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.media OWNER TO postgres;

--
-- Name: media_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.media_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.media_id_seq OWNER TO postgres;

--
-- Name: media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.media_id_seq OWNED BY public.media.id;


--
-- Name: menu_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_role (
    id bigint NOT NULL,
    role_name character varying(255) NOT NULL,
    menus_id integer NOT NULL
);


ALTER TABLE public.menu_role OWNER TO postgres;

--
-- Name: menu_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_role_id_seq OWNER TO postgres;

--
-- Name: menu_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_role_id_seq OWNED BY public.menu_role.id;


--
-- Name: menulist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menulist (
    id bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.menulist OWNER TO postgres;

--
-- Name: menulist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menulist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menulist_id_seq OWNER TO postgres;

--
-- Name: menulist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menulist_id_seq OWNED BY public.menulist.id;


--
-- Name: menus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menus (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    href character varying(255),
    icon character varying(255),
    slug character varying(255) NOT NULL,
    parent_id integer,
    menu_id integer NOT NULL,
    sequence integer NOT NULL
);


ALTER TABLE public.menus OWNER TO postgres;

--
-- Name: menus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menus_id_seq OWNER TO postgres;

--
-- Name: menus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menus_id_seq OWNED BY public.menus.id;


--
-- Name: meterai; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.meterai (
    id bigint NOT NULL,
    dokumen_id integer,
    serial_number character varying(255) NOT NULL,
    path character varying(255) NOT NULL,
    status integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    company_id integer
);


ALTER TABLE public.meterai OWNER TO postgres;

--
-- Name: meterai_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.meterai_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.meterai_id_seq OWNER TO postgres;

--
-- Name: meterai_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.meterai_id_seq OWNED BY public.meterai.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: model_has_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.model_has_permissions (
    permission_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_permissions OWNER TO postgres;

--
-- Name: model_has_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.model_has_roles (
    role_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_roles OWNER TO postgres;

--
-- Name: notes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notes (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    note_type character varying(255) NOT NULL,
    applies_to_date date NOT NULL,
    users_id integer NOT NULL,
    status_id integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.notes OWNER TO postgres;

--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notes_id_seq OWNER TO postgres;

--
-- Name: notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notes_id_seq OWNED BY public.notes.id;


--
-- Name: oauth_access_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_access_tokens (
    id character varying(100) NOT NULL,
    user_id bigint,
    client_id bigint NOT NULL,
    name character varying(255),
    scopes text,
    revoked boolean NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone
);


ALTER TABLE public.oauth_access_tokens OWNER TO postgres;

--
-- Name: oauth_auth_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_auth_codes (
    id character varying(100) NOT NULL,
    user_id bigint NOT NULL,
    client_id bigint NOT NULL,
    scopes text,
    revoked boolean NOT NULL,
    expires_at timestamp(0) without time zone
);


ALTER TABLE public.oauth_auth_codes OWNER TO postgres;

--
-- Name: oauth_clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_clients (
    id bigint NOT NULL,
    user_id bigint,
    name character varying(255) NOT NULL,
    secret character varying(100),
    provider character varying(255),
    redirect text NOT NULL,
    personal_access_client boolean NOT NULL,
    password_client boolean NOT NULL,
    revoked boolean NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.oauth_clients OWNER TO postgres;

--
-- Name: oauth_clients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_clients_id_seq OWNER TO postgres;

--
-- Name: oauth_clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_clients_id_seq OWNED BY public.oauth_clients.id;


--
-- Name: oauth_personal_access_clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_personal_access_clients (
    id bigint NOT NULL,
    client_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.oauth_personal_access_clients OWNER TO postgres;

--
-- Name: oauth_personal_access_clients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_personal_access_clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_personal_access_clients_id_seq OWNER TO postgres;

--
-- Name: oauth_personal_access_clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_personal_access_clients_id_seq OWNED BY public.oauth_personal_access_clients.id;


--
-- Name: oauth_refresh_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_refresh_tokens (
    id character varying(100) NOT NULL,
    access_token_id character varying(100) NOT NULL,
    revoked boolean NOT NULL,
    expires_at timestamp(0) without time zone
);


ALTER TABLE public.oauth_refresh_tokens OWNER TO postgres;

--
-- Name: paket_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.paket_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.paket_id_seq OWNER TO postgres;

--
-- Name: paket; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paket (
    id bigint DEFAULT nextval('public.paket_id_seq'::regclass) NOT NULL,
    name character varying(255) NOT NULL,
    icon character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    durasi integer,
    satuan character varying(255),
    company_id integer,
    jenis character varying(255),
    status integer,
    price integer,
    codename character varying,
    show boolean
);


ALTER TABLE public.paket OWNER TO postgres;

--
-- Name: paket_detail_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.paket_detail_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.paket_detail_id_seq OWNER TO postgres;

--
-- Name: paket_detail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paket_detail (
    id bigint DEFAULT nextval('public.paket_detail_id_seq'::regclass) NOT NULL,
    value character varying(255),
    satuan character varying(255),
    type character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    detail_name_id integer,
    company_id integer,
    status integer
);


ALTER TABLE public.paket_detail OWNER TO postgres;

--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_resets (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_resets OWNER TO postgres;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_access_tokens_id_seq OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: profile_approver; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.profile_approver (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    company_id integer
);


ALTER TABLE public.profile_approver OWNER TO postgres;

--
-- Name: profile_approver_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.profile_approver_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.profile_approver_id_seq OWNER TO postgres;

--
-- Name: profile_approver_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.profile_approver_id_seq OWNED BY public.profile_approver.id;


--
-- Name: quota_company; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quota_company (
    id bigint NOT NULL,
    paket_detail_id integer NOT NULL,
    company_id integer NOT NULL,
    quota character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    "all" integer
);


ALTER TABLE public.quota_company OWNER TO postgres;

--
-- Name: quota_company_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quota_company_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quota_company_id_seq OWNER TO postgres;

--
-- Name: quota_company_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quota_company_id_seq OWNED BY public.quota_company.id;


--
-- Name: reg_districts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_districts (
    id character(8) NOT NULL,
    regency_id character(5) NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.reg_districts OWNER TO postgres;

--
-- Name: reg_provinces; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_provinces (
    id character(2) NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.reg_provinces OWNER TO postgres;

--
-- Name: reg_regencies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_regencies (
    id character(5) NOT NULL,
    province_id character(2) NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.reg_regencies OWNER TO postgres;

--
-- Name: reg_villages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_villages (
    id character(13) NOT NULL,
    district_id character(8) NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.reg_villages OWNER TO postgres;

--
-- Name: role_has_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_has_permissions (
    permission_id bigint NOT NULL,
    role_id bigint NOT NULL
);


ALTER TABLE public.role_has_permissions OWNER TO postgres;

--
-- Name: role_hierarchy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_hierarchy (
    id bigint NOT NULL,
    role_id integer NOT NULL,
    hierarchy integer NOT NULL
);


ALTER TABLE public.role_hierarchy OWNER TO postgres;

--
-- Name: role_hierarchy_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.role_hierarchy_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_hierarchy_id_seq OWNER TO postgres;

--
-- Name: role_hierarchy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.role_hierarchy_id_seq OWNED BY public.role_hierarchy.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: speciments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.speciments (
    id bigint NOT NULL,
    users_id integer NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    file text
);


ALTER TABLE public.speciments OWNER TO postgres;

--
-- Name: speciments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.speciments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.speciments_id_seq OWNER TO postgres;

--
-- Name: speciments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.speciments_id_seq OWNED BY public.speciments.id;


--
-- Name: status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    class character varying(255) NOT NULL
);


ALTER TABLE public.status OWNER TO postgres;

--
-- Name: status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.status_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.status_id_seq OWNER TO postgres;

--
-- Name: status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.status_id_seq OWNED BY public.status.id;


--
-- Name: title; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.title (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    company_id integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    status integer
);


ALTER TABLE public.title OWNER TO postgres;

--
-- Name: title_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.title_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.title_id_seq OWNER TO postgres;

--
-- Name: title_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.title_id_seq OWNED BY public.title.id;


--
-- Name: tmp_download; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tmp_download (
    id bigint NOT NULL,
    dokumen_id character varying(255) NOT NULL,
    status integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.tmp_download OWNER TO postgres;

--
-- Name: tmp_download_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tmp_download_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tmp_download_id_seq OWNER TO postgres;

--
-- Name: tmp_download_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tmp_download_id_seq OWNED BY public.tmp_download.id;


--
-- Name: tmp_load; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tmp_load (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    type character varying
);


ALTER TABLE public.tmp_load OWNER TO postgres;

--
-- Name: tmp_load_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tmp_load_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tmp_load_id_seq OWNER TO postgres;

--
-- Name: tmp_load_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tmp_load_id_seq OWNED BY public.tmp_load.id;


--
-- Name: tmp_paket; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tmp_paket (
    id bigint NOT NULL,
    company_id integer NOT NULL,
    paket_id integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    transaction integer
);


ALTER TABLE public.tmp_paket OWNER TO postgres;

--
-- Name: tmp_paket_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tmp_paket_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tmp_paket_id_seq OWNER TO postgres;

--
-- Name: tmp_paket_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tmp_paket_id_seq OWNED BY public.tmp_paket.id;


--
-- Name: token_auth; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.token_auth (
    id bigint NOT NULL,
    token text NOT NULL,
    created timestamp(0) without time zone NOT NULL,
    expired timestamp(0) without time zone NOT NULL
);


ALTER TABLE public.token_auth OWNER TO postgres;

--
-- Name: token_auth_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.token_auth_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.token_auth_id_seq OWNER TO postgres;

--
-- Name: token_auth_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.token_auth_id_seq OWNED BY public.token_auth.id;


--
-- Name: transaction_in_odoo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transaction_in_odoo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transaction_in_odoo_id_seq OWNER TO postgres;

--
-- Name: transaction_in_odoo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transaction_in_odoo (
    id bigint DEFAULT nextval('public.transaction_in_odoo_id_seq'::regclass) NOT NULL,
    company_id integer,
    users_id integer,
    so_id integer,
    so_number character varying(255),
    account_move_id character varying(255),
    invoice_id character varying(255),
    payment_id character varying(255),
    payment_no character varying(255),
    payment_attach text,
    invoice_no character varying(255),
    payment_date character varying(255),
    invoice_attach text,
    is_approve boolean DEFAULT false,
    "namaPaket" character varying,
    "hargaPaket" character varying,
    "kodeUnik" character varying,
    ppn character varying,
    "methodeBayar" character varying
);


ALTER TABLE public.transaction_in_odoo OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    menuroles character varying(255) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    nik character varying(255),
    tempat_lahir character varying(255),
    tanggal_lahir date,
    hp character varying(255),
    alamat text,
    kota character varying(255),
    provinsi character varying(255),
    foto_ktp text,
    video text,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    status integer DEFAULT 0 NOT NULL,
    company_id integer,
    industry_id integer,
    title_id integer,
    departement_id integer,
    selfi text,
    foto_npwp text,
    res_partner_id text,
    time_first_login date,
    isexpired integer,
    payment_method character varying,
    key_admin boolean,
    otp character varying,
    exp character varying
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: brute_force id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brute_force ALTER COLUMN id SET DEFAULT nextval('public.brute_force_id_seq'::regclass);


--
-- Name: company id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company ALTER COLUMN id SET DEFAULT nextval('public.company_id_seq'::regclass);


--
-- Name: department id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.department ALTER COLUMN id SET DEFAULT nextval('public.department_id_seq'::regclass);


--
-- Name: detail_name id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_name ALTER COLUMN id SET DEFAULT nextval('public.detail_name_id_seq'::regclass);


--
-- Name: dok_base64 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dok_base64 ALTER COLUMN id SET DEFAULT nextval('public.dok_base64_id_seq'::regclass);


--
-- Name: dok_sign id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dok_sign ALTER COLUMN id SET DEFAULT nextval('public.dok_sign_id_seq'::regclass);


--
-- Name: dokumen id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dokumen ALTER COLUMN id SET DEFAULT nextval('public.dokumen_id_seq'::regclass);


--
-- Name: email_template id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_template ALTER COLUMN id SET DEFAULT nextval('public.email_template_id_seq'::regclass);


--
-- Name: example id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.example ALTER COLUMN id SET DEFAULT nextval('public.example_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: folder id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.folder ALTER COLUMN id SET DEFAULT nextval('public.folder_id_seq'::regclass);


--
-- Name: form id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form ALTER COLUMN id SET DEFAULT nextval('public.form_id_seq'::regclass);


--
-- Name: form_field id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_field ALTER COLUMN id SET DEFAULT nextval('public.form_field_id_seq'::regclass);


--
-- Name: history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history ALTER COLUMN id SET DEFAULT nextval('public.history_id_seq'::regclass);


--
-- Name: history_pemakaian id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history_pemakaian ALTER COLUMN id SET DEFAULT nextval('public.history_pemakaian_id_seq'::regclass);


--
-- Name: history_transaksi id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history_transaksi ALTER COLUMN id SET DEFAULT nextval('public.history_transaksi_id_seq'::regclass);


--
-- Name: industry id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.industry ALTER COLUMN id SET DEFAULT nextval('public.industry_id_seq'::regclass);


--
-- Name: link_regis id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.link_regis ALTER COLUMN id SET DEFAULT nextval('public.link_regis_id_seq'::regclass);


--
-- Name: list_signer id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list_signer ALTER COLUMN id SET DEFAULT nextval('public.list_signer_id_seq'::regclass);


--
-- Name: log_error id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.log_error ALTER COLUMN id SET DEFAULT nextval('public.log_error_id_seq'::regclass);


--
-- Name: map_approver id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.map_approver ALTER COLUMN id SET DEFAULT nextval('public.map_approver_id_seq'::regclass);


--
-- Name: map_company id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.map_company ALTER COLUMN id SET DEFAULT nextval('public.map_company_id_seq'::regclass);


--
-- Name: map_pricing id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.map_pricing ALTER COLUMN id SET DEFAULT nextval('public.map_pricing_id_seq'::regclass);


--
-- Name: media id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media ALTER COLUMN id SET DEFAULT nextval('public.media_id_seq'::regclass);


--
-- Name: menu_role id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_role ALTER COLUMN id SET DEFAULT nextval('public.menu_role_id_seq'::regclass);


--
-- Name: menulist id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menulist ALTER COLUMN id SET DEFAULT nextval('public.menulist_id_seq'::regclass);


--
-- Name: menus id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menus ALTER COLUMN id SET DEFAULT nextval('public.menus_id_seq'::regclass);


--
-- Name: meterai id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meterai ALTER COLUMN id SET DEFAULT nextval('public.meterai_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: notes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes ALTER COLUMN id SET DEFAULT nextval('public.notes_id_seq'::regclass);


--
-- Name: oauth_clients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_clients ALTER COLUMN id SET DEFAULT nextval('public.oauth_clients_id_seq'::regclass);


--
-- Name: oauth_personal_access_clients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_personal_access_clients ALTER COLUMN id SET DEFAULT nextval('public.oauth_personal_access_clients_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: profile_approver id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profile_approver ALTER COLUMN id SET DEFAULT nextval('public.profile_approver_id_seq'::regclass);


--
-- Name: quota_company id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quota_company ALTER COLUMN id SET DEFAULT nextval('public.quota_company_id_seq'::regclass);


--
-- Name: role_hierarchy id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_hierarchy ALTER COLUMN id SET DEFAULT nextval('public.role_hierarchy_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: speciments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.speciments ALTER COLUMN id SET DEFAULT nextval('public.speciments_id_seq'::regclass);


--
-- Name: status id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status ALTER COLUMN id SET DEFAULT nextval('public.status_id_seq'::regclass);


--
-- Name: title id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.title ALTER COLUMN id SET DEFAULT nextval('public.title_id_seq'::regclass);


--
-- Name: tmp_download id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tmp_download ALTER COLUMN id SET DEFAULT nextval('public.tmp_download_id_seq'::regclass);


--
-- Name: tmp_load id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tmp_load ALTER COLUMN id SET DEFAULT nextval('public.tmp_load_id_seq'::regclass);


--
-- Name: tmp_paket id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tmp_paket ALTER COLUMN id SET DEFAULT nextval('public.tmp_paket_id_seq'::regclass);


--
-- Name: token_auth id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_auth ALTER COLUMN id SET DEFAULT nextval('public.token_auth_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: account_payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_payment (id, move_id, is_reconciled, is_matched, partner_bank_id, is_internal_transfer, payment_method_id, amount, payment_type, partner_type, payment_reference, currency_id, partner_id, destination_account_id, message_main_attachment_id, create_uid, create_date, write_uid, write_date, payment_transaction_id, payment_token_id, name, state, journal_id, payment_date, is_deposit, is_deposit_return, deposit_payment_id, account_id, writeoff_account_id, partner_name, account_code, writeoff_account_code, deposit_status, move_name) FROM stdin;
\.
COPY public.account_payment (id, move_id, is_reconciled, is_matched, partner_bank_id, is_internal_transfer, payment_method_id, amount, payment_type, partner_type, payment_reference, currency_id, partner_id, destination_account_id, message_main_attachment_id, create_uid, create_date, write_uid, write_date, payment_transaction_id, payment_token_id, name, state, journal_id, payment_date, is_deposit, is_deposit_return, deposit_payment_id, account_id, writeoff_account_id, partner_name, account_code, writeoff_account_code, deposit_status, move_name) FROM '$$PATH$$/3625.dat';

--
-- Data for Name: auth_client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_client (id, company_id, token_name, token, created_at, updated_at) FROM stdin;
\.
COPY public.auth_client (id, company_id, token_name, token, created_at, updated_at) FROM '$$PATH$$/3627.dat';

--
-- Data for Name: brute_force; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.brute_force (id, ip_address, token, email, created_at, updated_at) FROM stdin;
\.
COPY public.brute_force (id, ip_address, token, email, created_at, updated_at) FROM '$$PATH$$/3628.dat';

--
-- Data for Name: company; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company (id, name, created_at, updated_at, alamat, email, tlp, res_partner_id, company_type, type, parent, logo, slug, payment_method, isenterprise, lama, status) FROM stdin;
\.
COPY public.company (id, name, created_at, updated_at, alamat, email, tlp, res_partner_id, company_type, type, parent, logo, slug, payment_method, isenterprise, lama, status) FROM '$$PATH$$/3630.dat';

--
-- Data for Name: department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.department (id, name, created_at, updated_at, company_id, status) FROM stdin;
\.
COPY public.department (id, name, created_at, updated_at, company_id, status) FROM '$$PATH$$/3632.dat';

--
-- Data for Name: detail_name; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detail_name (id, name, description, type, created_at, updated_at) FROM stdin;
\.
COPY public.detail_name (id, name, description, type, created_at, updated_at) FROM '$$PATH$$/3634.dat';

--
-- Data for Name: dok_base64; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dok_base64 (id, dokumen_id, "base64Doc", status, created_at, updated_at, "desc") FROM stdin;
\.
COPY public.dok_base64 (id, dokumen_id, "base64Doc", status, created_at, updated_at, "desc") FROM '$$PATH$$/3636.dat';

--
-- Data for Name: dok_sign; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dok_sign (id, dokumen_id, "orderId", name, status, created_at, updated_at, "parallelId", users_id) FROM stdin;
\.
COPY public.dok_sign (id, dokumen_id, "orderId", name, status, created_at, updated_at, "parallelId", users_id) FROM '$$PATH$$/3638.dat';

--
-- Data for Name: dokumen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dokumen (id, users_id, name, realname, status_id, created_at, updated_at, tipe, step, id_bulk) FROM stdin;
\.
COPY public.dokumen (id, users_id, name, realname, status_id, created_at, updated_at, tipe, step, id_bulk) FROM '$$PATH$$/3640.dat';

--
-- Data for Name: email_template; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_template (id, created_at, updated_at, content, name, subject, company_id, status, type, logo_header) FROM stdin;
\.
COPY public.email_template (id, created_at, updated_at, content, name, subject, company_id, status, type, logo_header) FROM '$$PATH$$/3642.dat';

--
-- Data for Name: example; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.example (id, created_at, updated_at, name, description, status_id) FROM stdin;
\.
COPY public.example (id, created_at, updated_at, name, description, status_id) FROM '$$PATH$$/3644.dat';

--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.failed_jobs (id, connection, queue, payload, exception, failed_at) FROM stdin;
\.
COPY public.failed_jobs (id, connection, queue, payload, exception, failed_at) FROM '$$PATH$$/3646.dat';

--
-- Data for Name: folder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.folder (id, created_at, updated_at, name, folder_id, resource) FROM stdin;
\.
COPY public.folder (id, created_at, updated_at, name, folder_id, resource) FROM '$$PATH$$/3648.dat';

--
-- Data for Name: form; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.form (id, created_at, updated_at, name, table_name, read, edit, add, delete, pagination) FROM stdin;
\.
COPY public.form (id, created_at, updated_at, name, table_name, read, edit, add, delete, pagination) FROM '$$PATH$$/3650.dat';

--
-- Data for Name: form_field; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.form_field (id, created_at, updated_at, name, type, browse, read, edit, add, relation_table, relation_column, form_id, column_name) FROM stdin;
\.
COPY public.form_field (id, created_at, updated_at, name, type, browse, read, edit, add, relation_table, relation_column, form_id, column_name) FROM '$$PATH$$/3651.dat';

--
-- Data for Name: history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.history (id, dokumen_id, users_id, description, created_at, updated_at) FROM stdin;
\.
COPY public.history (id, dokumen_id, users_id, description, created_at, updated_at) FROM '$$PATH$$/3654.dat';

--
-- Data for Name: history_pemakaian; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.history_pemakaian (id, users_id, paket_detail_id, created_at, updated_at, description) FROM stdin;
\.
COPY public.history_pemakaian (id, users_id, paket_detail_id, created_at, updated_at, description) FROM '$$PATH$$/3656.dat';

--
-- Data for Name: history_transaksi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.history_transaksi (id, company_id, paket_id, description, type, created_at, updated_at) FROM stdin;
\.
COPY public.history_transaksi (id, company_id, paket_id, description, type, created_at, updated_at) FROM '$$PATH$$/3658.dat';

--
-- Data for Name: industry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.industry (id, name, company_id, created_at, updated_at) FROM stdin;
\.
COPY public.industry (id, name, company_id, created_at, updated_at) FROM '$$PATH$$/3660.dat';

--
-- Data for Name: jenis_dokumen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jenis_dokumen (id, nama, created_at, updated_at) FROM stdin;
\.
COPY public.jenis_dokumen (id, nama, created_at, updated_at) FROM '$$PATH$$/3662.dat';

--
-- Data for Name: link_regis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.link_regis (id, company_id, param, expired, created_at, updated_at) FROM stdin;
\.
COPY public.link_regis (id, company_id, param, expired, created_at, updated_at) FROM '$$PATH$$/3663.dat';

--
-- Data for Name: list_signer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.list_signer (id, users_id, step, created_at, updated_at, dokumen_id, page, x1, x2, y1, y2, lower_left_x, lower_left_y, upper_right_x, upper_right_y, "isSign", email, reason, location) FROM stdin;
\.
COPY public.list_signer (id, users_id, step, created_at, updated_at, dokumen_id, page, x1, x2, y1, y2, lower_left_x, lower_left_y, upper_right_x, upper_right_y, "isSign", email, reason, location) FROM '$$PATH$$/3665.dat';

--
-- Data for Name: log_error; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.log_error (id, ip, users_id, url, param, "desc", status, created_at, updated_at) FROM stdin;
\.
COPY public.log_error (id, ip, users_id, url, param, "desc", status, created_at, updated_at) FROM '$$PATH$$/3667.dat';

--
-- Data for Name: map_approver; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.map_approver (id, users_id, profile_id, created_at, updated_at) FROM stdin;
\.
COPY public.map_approver (id, users_id, profile_id, created_at, updated_at) FROM '$$PATH$$/3669.dat';

--
-- Data for Name: map_company; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.map_company (id, paket_id, company_id, created_at, updated_at, expired_date) FROM stdin;
\.
COPY public.map_company (id, paket_id, company_id, created_at, updated_at, expired_date) FROM '$$PATH$$/3671.dat';

--
-- Data for Name: map_paket; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.map_paket (id, paket_id, paket_detial_id, created_at, updated_at) FROM stdin;
\.
COPY public.map_paket (id, paket_id, paket_detial_id, created_at, updated_at) FROM '$$PATH$$/3673.dat';

--
-- Data for Name: map_pricing; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.map_pricing (id, company_id, name_id, created_at, updated_at, price, qty) FROM stdin;
\.
COPY public.map_pricing (id, company_id, name_id, created_at, updated_at, price, qty) FROM '$$PATH$$/3675.dat';

--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media (id, model_type, model_id, collection_name, name, file_name, mime_type, disk, conversions_disk, size, uuid, manipulations, custom_properties, responsive_images, order_column, created_at, updated_at) FROM stdin;
\.
COPY public.media (id, model_type, model_id, collection_name, name, file_name, mime_type, disk, conversions_disk, size, uuid, manipulations, custom_properties, responsive_images, order_column, created_at, updated_at) FROM '$$PATH$$/3677.dat';

--
-- Data for Name: menu_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_role (id, role_name, menus_id) FROM stdin;
\.
COPY public.menu_role (id, role_name, menus_id) FROM '$$PATH$$/3679.dat';

--
-- Data for Name: menulist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menulist (id, name) FROM stdin;
\.
COPY public.menulist (id, name) FROM '$$PATH$$/3681.dat';

--
-- Data for Name: menus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menus (id, name, href, icon, slug, parent_id, menu_id, sequence) FROM stdin;
\.
COPY public.menus (id, name, href, icon, slug, parent_id, menu_id, sequence) FROM '$$PATH$$/3683.dat';

--
-- Data for Name: meterai; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.meterai (id, dokumen_id, serial_number, path, status, created_at, updated_at, company_id) FROM stdin;
\.
COPY public.meterai (id, dokumen_id, serial_number, path, status, created_at, updated_at, company_id) FROM '$$PATH$$/3685.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, migration, batch) FROM stdin;
\.
COPY public.migrations (id, migration, batch) FROM '$$PATH$$/3687.dat';

--
-- Data for Name: model_has_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.model_has_permissions (permission_id, model_type, model_id) FROM stdin;
\.
COPY public.model_has_permissions (permission_id, model_type, model_id) FROM '$$PATH$$/3689.dat';

--
-- Data for Name: model_has_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.model_has_roles (role_id, model_type, model_id) FROM stdin;
\.
COPY public.model_has_roles (role_id, model_type, model_id) FROM '$$PATH$$/3690.dat';

--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notes (id, title, content, note_type, applies_to_date, users_id, status_id, created_at, updated_at) FROM stdin;
\.
COPY public.notes (id, title, content, note_type, applies_to_date, users_id, status_id, created_at, updated_at) FROM '$$PATH$$/3691.dat';

--
-- Data for Name: oauth_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_access_tokens (id, user_id, client_id, name, scopes, revoked, created_at, updated_at, expires_at) FROM stdin;
\.
COPY public.oauth_access_tokens (id, user_id, client_id, name, scopes, revoked, created_at, updated_at, expires_at) FROM '$$PATH$$/3693.dat';

--
-- Data for Name: oauth_auth_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_auth_codes (id, user_id, client_id, scopes, revoked, expires_at) FROM stdin;
\.
COPY public.oauth_auth_codes (id, user_id, client_id, scopes, revoked, expires_at) FROM '$$PATH$$/3694.dat';

--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_clients (id, user_id, name, secret, provider, redirect, personal_access_client, password_client, revoked, created_at, updated_at) FROM stdin;
\.
COPY public.oauth_clients (id, user_id, name, secret, provider, redirect, personal_access_client, password_client, revoked, created_at, updated_at) FROM '$$PATH$$/3695.dat';

--
-- Data for Name: oauth_personal_access_clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_personal_access_clients (id, client_id, created_at, updated_at) FROM stdin;
\.
COPY public.oauth_personal_access_clients (id, client_id, created_at, updated_at) FROM '$$PATH$$/3697.dat';

--
-- Data for Name: oauth_refresh_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_refresh_tokens (id, access_token_id, revoked, expires_at) FROM stdin;
\.
COPY public.oauth_refresh_tokens (id, access_token_id, revoked, expires_at) FROM '$$PATH$$/3699.dat';

--
-- Data for Name: paket; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paket (id, name, icon, created_at, updated_at, durasi, satuan, company_id, jenis, status, price, codename, show) FROM stdin;
\.
COPY public.paket (id, name, icon, created_at, updated_at, durasi, satuan, company_id, jenis, status, price, codename, show) FROM '$$PATH$$/3700.dat';

--
-- Data for Name: paket_detail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paket_detail (id, value, satuan, type, created_at, updated_at, detail_name_id, company_id, status) FROM stdin;
\.
COPY public.paket_detail (id, value, satuan, type, created_at, updated_at, detail_name_id, company_id, status) FROM '$$PATH$$/3701.dat';

--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_resets (email, token, created_at) FROM stdin;
\.
COPY public.password_resets (email, token, created_at) FROM '$$PATH$$/3704.dat';

--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (id, name, guard_name, created_at, updated_at) FROM stdin;
\.
COPY public.permissions (id, name, guard_name, created_at, updated_at) FROM '$$PATH$$/3705.dat';

--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, created_at, updated_at) FROM stdin;
\.
COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, created_at, updated_at) FROM '$$PATH$$/3707.dat';

--
-- Data for Name: profile_approver; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.profile_approver (id, name, status, created_at, updated_at, company_id) FROM stdin;
\.
COPY public.profile_approver (id, name, status, created_at, updated_at, company_id) FROM '$$PATH$$/3709.dat';

--
-- Data for Name: quota_company; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quota_company (id, paket_detail_id, company_id, quota, created_at, updated_at, "all") FROM stdin;
\.
COPY public.quota_company (id, paket_detail_id, company_id, quota, created_at, updated_at, "all") FROM '$$PATH$$/3711.dat';

--
-- Data for Name: reg_districts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_districts (id, regency_id, name) FROM stdin;
\.
COPY public.reg_districts (id, regency_id, name) FROM '$$PATH$$/3713.dat';

--
-- Data for Name: reg_provinces; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_provinces (id, name) FROM stdin;
\.
COPY public.reg_provinces (id, name) FROM '$$PATH$$/3714.dat';

--
-- Data for Name: reg_regencies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_regencies (id, province_id, name) FROM stdin;
\.
COPY public.reg_regencies (id, province_id, name) FROM '$$PATH$$/3715.dat';

--
-- Data for Name: reg_villages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_villages (id, district_id, name) FROM stdin;
\.
COPY public.reg_villages (id, district_id, name) FROM '$$PATH$$/3716.dat';

--
-- Data for Name: role_has_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_has_permissions (permission_id, role_id) FROM stdin;
\.
COPY public.role_has_permissions (permission_id, role_id) FROM '$$PATH$$/3717.dat';

--
-- Data for Name: role_hierarchy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_hierarchy (id, role_id, hierarchy) FROM stdin;
\.
COPY public.role_hierarchy (id, role_id, hierarchy) FROM '$$PATH$$/3718.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, guard_name, created_at, updated_at) FROM stdin;
\.
COPY public.roles (id, name, guard_name, created_at, updated_at) FROM '$$PATH$$/3720.dat';

--
-- Data for Name: speciments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.speciments (id, users_id, name, created_at, updated_at, file) FROM stdin;
\.
COPY public.speciments (id, users_id, name, created_at, updated_at, file) FROM '$$PATH$$/3722.dat';

--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status (id, name, class) FROM stdin;
\.
COPY public.status (id, name, class) FROM '$$PATH$$/3724.dat';

--
-- Data for Name: title; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.title (id, name, company_id, created_at, updated_at, status) FROM stdin;
\.
COPY public.title (id, name, company_id, created_at, updated_at, status) FROM '$$PATH$$/3726.dat';

--
-- Data for Name: tmp_download; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tmp_download (id, dokumen_id, status, created_at, updated_at) FROM stdin;
\.
COPY public.tmp_download (id, dokumen_id, status, created_at, updated_at) FROM '$$PATH$$/3728.dat';

--
-- Data for Name: tmp_load; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tmp_load (id, created_at, updated_at, type) FROM stdin;
\.
COPY public.tmp_load (id, created_at, updated_at, type) FROM '$$PATH$$/3730.dat';

--
-- Data for Name: tmp_paket; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tmp_paket (id, company_id, paket_id, created_at, updated_at, transaction) FROM stdin;
\.
COPY public.tmp_paket (id, company_id, paket_id, created_at, updated_at, transaction) FROM '$$PATH$$/3732.dat';

--
-- Data for Name: token_auth; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.token_auth (id, token, created, expired) FROM stdin;
\.
COPY public.token_auth (id, token, created, expired) FROM '$$PATH$$/3734.dat';

--
-- Data for Name: transaction_in_odoo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transaction_in_odoo (id, company_id, users_id, so_id, so_number, account_move_id, invoice_id, payment_id, payment_no, payment_attach, invoice_no, payment_date, invoice_attach, is_approve, "namaPaket", "hargaPaket", "kodeUnik", ppn, "methodeBayar") FROM stdin;
\.
COPY public.transaction_in_odoo (id, company_id, users_id, so_id, so_number, account_move_id, invoice_id, payment_id, payment_no, payment_attach, invoice_no, payment_date, invoice_attach, is_approve, "namaPaket", "hargaPaket", "kodeUnik", ppn, "methodeBayar") FROM '$$PATH$$/3737.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, email_verified_at, password, menuroles, is_active, nik, tempat_lahir, tanggal_lahir, hp, alamat, kota, provinsi, foto_ktp, video, remember_token, created_at, updated_at, deleted_at, status, company_id, industry_id, title_id, departement_id, selfi, foto_npwp, res_partner_id, time_first_login, isexpired, payment_method, key_admin, otp, exp) FROM stdin;
\.
COPY public.users (id, name, email, email_verified_at, password, menuroles, is_active, nik, tempat_lahir, tanggal_lahir, hp, alamat, kota, provinsi, foto_ktp, video, remember_token, created_at, updated_at, deleted_at, status, company_id, industry_id, title_id, departement_id, selfi, foto_npwp, res_partner_id, time_first_login, isexpired, payment_method, key_admin, otp, exp) FROM '$$PATH$$/3738.dat';

--
-- Name: account_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_payment_id_seq', 1, false);


--
-- Name: auth_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_client_id_seq', 1, true);


--
-- Name: brute_force_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.brute_force_id_seq', 1, true);


--
-- Name: company_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.company_id_seq', 1, false);


--
-- Name: department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.department_id_seq', 1, false);


--
-- Name: detail_name_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.detail_name_id_seq', 9, true);


--
-- Name: dok_base64_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dok_base64_id_seq', 1, false);


--
-- Name: dok_sign_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dok_sign_id_seq', 1, false);


--
-- Name: dokumen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dokumen_id_seq', 4, true);


--
-- Name: email_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_template_id_seq', 1, false);


--
-- Name: example_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.example_id_seq', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: folder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.folder_id_seq', 1, false);


--
-- Name: form_field_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.form_field_id_seq', 1, false);


--
-- Name: form_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.form_id_seq', 1, false);


--
-- Name: history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.history_id_seq', 1, false);


--
-- Name: history_pemakaian_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.history_pemakaian_id_seq', 12, true);


--
-- Name: history_transaksi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.history_transaksi_id_seq', 1, false);


--
-- Name: industry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.industry_id_seq', 1, false);


--
-- Name: link_regis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.link_regis_id_seq', 1, false);


--
-- Name: list_signer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.list_signer_id_seq', 3, true);


--
-- Name: log_error_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.log_error_id_seq', 1, false);


--
-- Name: map_approver_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.map_approver_id_seq', 1, false);


--
-- Name: map_company_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.map_company_id_seq', 4, true);


--
-- Name: map_paket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.map_paket_id_seq', 30, true);


--
-- Name: map_pricing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.map_pricing_id_seq', 5, true);


--
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.media_id_seq', 1, false);


--
-- Name: menu_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_role_id_seq', 414, true);


--
-- Name: menulist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menulist_id_seq', 2, true);


--
-- Name: menus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menus_id_seq', 105, true);


--
-- Name: meterai_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.meterai_id_seq', 19, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 1, false);


--
-- Name: notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notes_id_seq', 1, false);


--
-- Name: oauth_clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_clients_id_seq', 1, false);


--
-- Name: oauth_personal_access_clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_personal_access_clients_id_seq', 1, false);


--
-- Name: paket_detail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.paket_detail_id_seq', 24, true);


--
-- Name: paket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.paket_id_seq', 11, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.permissions_id_seq', 5, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, false);


--
-- Name: profile_approver_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.profile_approver_id_seq', 1, false);


--
-- Name: quota_company_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quota_company_id_seq', 4, true);


--
-- Name: role_hierarchy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.role_hierarchy_id_seq', 10, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 11, true);


--
-- Name: speciments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.speciments_id_seq', 1, false);


--
-- Name: status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.status_id_seq', 1, false);


--
-- Name: title_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.title_id_seq', 1, false);


--
-- Name: tmp_download_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tmp_download_id_seq', 1, false);


--
-- Name: tmp_load_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tmp_load_id_seq', 1, false);


--
-- Name: tmp_paket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tmp_paket_id_seq', 1, false);


--
-- Name: token_auth_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.token_auth_id_seq', 1, false);


--
-- Name: transaction_in_odoo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transaction_in_odoo_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: account_payment account_payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_payment
    ADD CONSTRAINT account_payment_pkey PRIMARY KEY (id);


--
-- Name: auth_client auth_client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_client
    ADD CONSTRAINT auth_client_pkey PRIMARY KEY (id);


--
-- Name: brute_force brute_force_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brute_force
    ADD CONSTRAINT brute_force_pkey PRIMARY KEY (id);


--
-- Name: company company_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company
    ADD CONSTRAINT company_pkey PRIMARY KEY (id);


--
-- Name: department department_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.department
    ADD CONSTRAINT department_pkey PRIMARY KEY (id);


--
-- Name: detail_name detail_name_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_name
    ADD CONSTRAINT detail_name_pkey PRIMARY KEY (id);


--
-- Name: dok_base64 dok_base64_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dok_base64
    ADD CONSTRAINT dok_base64_pkey PRIMARY KEY (id);


--
-- Name: dok_sign dok_sign_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dok_sign
    ADD CONSTRAINT dok_sign_pkey PRIMARY KEY (id);


--
-- Name: dokumen dokumen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dokumen
    ADD CONSTRAINT dokumen_pkey PRIMARY KEY (id);


--
-- Name: email_template email_template_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_template
    ADD CONSTRAINT email_template_pkey PRIMARY KEY (id);


--
-- Name: example example_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.example
    ADD CONSTRAINT example_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: folder folder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT folder_pkey PRIMARY KEY (id);


--
-- Name: form_field form_field_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_field
    ADD CONSTRAINT form_field_pkey PRIMARY KEY (id);


--
-- Name: form form_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form
    ADD CONSTRAINT form_pkey PRIMARY KEY (id);


--
-- Name: history_pemakaian history_pemakaian_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history_pemakaian
    ADD CONSTRAINT history_pemakaian_pkey PRIMARY KEY (id);


--
-- Name: history history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT history_pkey PRIMARY KEY (id);


--
-- Name: history_transaksi history_transaksi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history_transaksi
    ADD CONSTRAINT history_transaksi_pkey PRIMARY KEY (id);


--
-- Name: industry industry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.industry
    ADD CONSTRAINT industry_pkey PRIMARY KEY (id);


--
-- Name: jenis_dokumen jenis_dokumen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jenis_dokumen
    ADD CONSTRAINT jenis_dokumen_pkey PRIMARY KEY (id);


--
-- Name: link_regis link_regis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.link_regis
    ADD CONSTRAINT link_regis_pkey PRIMARY KEY (id);


--
-- Name: list_signer list_signer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list_signer
    ADD CONSTRAINT list_signer_pkey PRIMARY KEY (id);


--
-- Name: log_error log_error_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.log_error
    ADD CONSTRAINT log_error_pkey PRIMARY KEY (id);


--
-- Name: map_approver map_approver_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.map_approver
    ADD CONSTRAINT map_approver_pkey PRIMARY KEY (id);


--
-- Name: map_company map_company_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.map_company
    ADD CONSTRAINT map_company_pkey PRIMARY KEY (id);


--
-- Name: map_paket map_paket_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.map_paket
    ADD CONSTRAINT map_paket_pkey PRIMARY KEY (id);


--
-- Name: map_pricing map_pricing_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.map_pricing
    ADD CONSTRAINT map_pricing_pkey PRIMARY KEY (id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: menu_role menu_role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_role
    ADD CONSTRAINT menu_role_pkey PRIMARY KEY (id);


--
-- Name: menulist menulist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menulist
    ADD CONSTRAINT menulist_pkey PRIMARY KEY (id);


--
-- Name: menus menus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menus
    ADD CONSTRAINT menus_pkey PRIMARY KEY (id);


--
-- Name: meterai meterai_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meterai
    ADD CONSTRAINT meterai_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: model_has_permissions model_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_pkey PRIMARY KEY (permission_id, model_id, model_type);


--
-- Name: model_has_roles model_has_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_pkey PRIMARY KEY (role_id, model_id, model_type);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_tokens oauth_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT oauth_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_auth_codes oauth_auth_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_auth_codes
    ADD CONSTRAINT oauth_auth_codes_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_personal_access_clients oauth_personal_access_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_personal_access_clients
    ADD CONSTRAINT oauth_personal_access_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_refresh_tokens oauth_refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_refresh_tokens
    ADD CONSTRAINT oauth_refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: paket_detail paket_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paket_detail
    ADD CONSTRAINT paket_detail_pkey PRIMARY KEY (id);


--
-- Name: paket paket_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paket
    ADD CONSTRAINT paket_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: profile_approver profile_approver_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profile_approver
    ADD CONSTRAINT profile_approver_pkey PRIMARY KEY (id);


--
-- Name: quota_company quota_company_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quota_company
    ADD CONSTRAINT quota_company_pkey PRIMARY KEY (id);


--
-- Name: reg_districts reg_districts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_districts
    ADD CONSTRAINT reg_districts_pkey PRIMARY KEY (id);


--
-- Name: reg_provinces reg_provinces_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_provinces
    ADD CONSTRAINT reg_provinces_pkey PRIMARY KEY (id);


--
-- Name: reg_regencies reg_regencies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_regencies
    ADD CONSTRAINT reg_regencies_pkey PRIMARY KEY (id);


--
-- Name: reg_villages reg_villages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_villages
    ADD CONSTRAINT reg_villages_pkey PRIMARY KEY (id);


--
-- Name: role_has_permissions role_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_pkey PRIMARY KEY (permission_id, role_id);


--
-- Name: role_hierarchy role_hierarchy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_hierarchy
    ADD CONSTRAINT role_hierarchy_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: speciments speciments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.speciments
    ADD CONSTRAINT speciments_pkey PRIMARY KEY (id);


--
-- Name: status status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_pkey PRIMARY KEY (id);


--
-- Name: title title_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.title
    ADD CONSTRAINT title_pkey PRIMARY KEY (id);


--
-- Name: tmp_download tmp_download_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tmp_download
    ADD CONSTRAINT tmp_download_pkey PRIMARY KEY (id);


--
-- Name: tmp_load tmp_load_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tmp_load
    ADD CONSTRAINT tmp_load_pkey PRIMARY KEY (id);


--
-- Name: tmp_paket tmp_paket_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tmp_paket
    ADD CONSTRAINT tmp_paket_pkey PRIMARY KEY (id);


--
-- Name: token_auth token_auth_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_auth
    ADD CONSTRAINT token_auth_pkey PRIMARY KEY (id);


--
-- Name: transaction_in_odoo transaction_in_odoo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction_in_odoo
    ADD CONSTRAINT transaction_in_odoo_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: account_payment_message_main_attachment_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_payment_message_main_attachment_id_index ON public.account_payment USING btree (message_main_attachment_id);


--
-- Name: account_payment_state_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_payment_state_index ON public.account_payment USING btree (state);


--
-- Name: approver_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX approver_index ON public.map_approver USING btree (users_id, profile_id);


--
-- Name: companyIndex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "companyIndex" ON public.auth_client USING btree (company_id);


--
-- Name: districts_regency_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX districts_regency_id_index ON public.reg_districts USING btree (regency_id);


--
-- Name: ind_dok; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ind_dok ON public.dok_sign USING btree (dokumen_id);


--
-- Name: ind_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ind_status ON public.dok_sign USING btree (status);


--
-- Name: ind_users; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ind_users ON public.dok_sign USING btree (users_id);


--
-- Name: index_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_company ON public.department USING btree (company_id);


--
-- Name: list_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_index ON public.list_signer USING btree (step, users_id, dokumen_id);


--
-- Name: mapCompanyIndex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "mapCompanyIndex" ON public.map_company USING btree (paket_id, company_id);


--
-- Name: media_model_type_model_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_model_type_model_id_index ON public.media USING btree (model_type, model_id);


--
-- Name: meterai_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX meterai_index ON public.meterai USING btree (dokumen_id, serial_number, status, company_id);


--
-- Name: model_has_permissions_model_id_model_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX model_has_permissions_model_id_model_type_index ON public.model_has_permissions USING btree (model_id, model_type);


--
-- Name: model_has_roles_model_id_model_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX model_has_roles_model_id_model_type_index ON public.model_has_roles USING btree (model_id, model_type);


--
-- Name: oauth_access_tokens_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_access_tokens_user_id_index ON public.oauth_access_tokens USING btree (user_id);


--
-- Name: oauth_auth_codes_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_auth_codes_user_id_index ON public.oauth_auth_codes USING btree (user_id);


--
-- Name: oauth_clients_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_clients_user_id_index ON public.oauth_clients USING btree (user_id);


--
-- Name: oauth_refresh_tokens_access_token_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_refresh_tokens_access_token_id_index ON public.oauth_refresh_tokens USING btree (access_token_id);


--
-- Name: paketIndex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "paketIndex" ON public.map_paket USING btree (paket_id, paket_detial_id);


--
-- Name: password_resets_email_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX password_resets_email_index ON public.password_resets USING btree (email);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: regencies_province_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX regencies_province_id_index ON public.reg_regencies USING btree (province_id);


--
-- Name: status_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX status_index ON public.dok_base64 USING btree (status);


--
-- Name: token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX token ON public.auth_client USING btree (token);


--
-- Name: users_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_index ON public.dokumen USING btree (users_id, status_id, step);


--
-- Name: villages_district_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX villages_district_id_index ON public.reg_villages USING btree (district_id);


--
-- Name: industry company; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.industry
    ADD CONSTRAINT company FOREIGN KEY (company_id) REFERENCES public.company(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: map_company company; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.map_company
    ADD CONSTRAINT company FOREIGN KEY (company_id) REFERENCES public.company(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: paket company; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paket
    ADD CONSTRAINT company FOREIGN KEY (company_id) REFERENCES public.company(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: profile_approver company; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profile_approver
    ADD CONSTRAINT company FOREIGN KEY (company_id) REFERENCES public.company(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: quota_company company; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quota_company
    ADD CONSTRAINT company FOREIGN KEY (company_id) REFERENCES public.company(id) NOT VALID;


--
-- Name: title company; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.title
    ADD CONSTRAINT company FOREIGN KEY (company_id) REFERENCES public.company(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: email_template company; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_template
    ADD CONSTRAINT company FOREIGN KEY (company_id) REFERENCES public.company(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: history_transaksi company; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history_transaksi
    ADD CONSTRAINT company FOREIGN KEY (company_id) REFERENCES public.company(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: paket_detail detail_name; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paket_detail
    ADD CONSTRAINT detail_name FOREIGN KEY (detail_name_id) REFERENCES public.detail_name(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: reg_districts district_regency_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_districts
    ADD CONSTRAINT district_regency_foreign FOREIGN KEY (regency_id) REFERENCES public.reg_regencies(id);


--
-- Name: dok_sign dok_sign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dok_sign
    ADD CONSTRAINT dok_sign FOREIGN KEY (dokumen_id) REFERENCES public.dokumen(id) NOT VALID;


--
-- Name: history dokumen; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT dokumen FOREIGN KEY (dokumen_id) REFERENCES public.dokumen(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: meterai dokumen; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meterai
    ADD CONSTRAINT dokumen FOREIGN KEY (dokumen_id) REFERENCES public.dokumen(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: users fk_company; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_company FOREIGN KEY (company_id) REFERENCES public.company(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: form_field form; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_field
    ADD CONSTRAINT form FOREIGN KEY (form_id) REFERENCES public.form(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: menu_role menu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_role
    ADD CONSTRAINT menu FOREIGN KEY (menus_id) REFERENCES public.menus(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: model_has_permissions model_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: model_has_roles model_has_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: map_company paket; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.map_company
    ADD CONSTRAINT paket FOREIGN KEY (paket_id) REFERENCES public.paket(id) NOT VALID;


--
-- Name: map_paket paket; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.map_paket
    ADD CONSTRAINT paket FOREIGN KEY (paket_id) REFERENCES public.paket(id) NOT VALID;


--
-- Name: history_transaksi paket; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history_transaksi
    ADD CONSTRAINT paket FOREIGN KEY (paket_id) REFERENCES public.paket(id) NOT VALID;


--
-- Name: history_pemakaian paket_detail; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history_pemakaian
    ADD CONSTRAINT paket_detail FOREIGN KEY (paket_detail_id) REFERENCES public.paket_detail(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: map_paket paket_detail; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.map_paket
    ADD CONSTRAINT paket_detail FOREIGN KEY (paket_detial_id) REFERENCES public.paket_detail(id) NOT VALID;


--
-- Name: quota_company paket_detail; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quota_company
    ADD CONSTRAINT paket_detail FOREIGN KEY (paket_detail_id) REFERENCES public.paket_detail(id) NOT VALID;


--
-- Name: map_approver profile; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.map_approver
    ADD CONSTRAINT profile FOREIGN KEY (profile_id) REFERENCES public.profile_approver(id) NOT VALID;


--
-- Name: reg_regencies regency_province_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_regencies
    ADD CONSTRAINT regency_province_foreign FOREIGN KEY (province_id) REFERENCES public.reg_provinces(id);


--
-- Name: role_hierarchy role; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_hierarchy
    ADD CONSTRAINT role FOREIGN KEY (role_id) REFERENCES public.roles(id) NOT VALID;


--
-- Name: role_has_permissions role_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: dokumen status; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dokumen
    ADD CONSTRAINT status FOREIGN KEY (status_id) REFERENCES public.status(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: history user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT "user" FOREIGN KEY (users_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: history_pemakaian user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history_pemakaian
    ADD CONSTRAINT "user" FOREIGN KEY (users_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: list_signer user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list_signer
    ADD CONSTRAINT "user" FOREIGN KEY (users_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: map_approver user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.map_approver
    ADD CONSTRAINT "user" FOREIGN KEY (users_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: speciments user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.speciments
    ADD CONSTRAINT "user" FOREIGN KEY (users_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: dokumen user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dokumen
    ADD CONSTRAINT "user" FOREIGN KEY (users_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: reg_villages village_district_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_villages
    ADD CONSTRAINT village_district_foreign FOREIGN KEY (district_id) REFERENCES public.reg_districts(id);


--
-- PostgreSQL database dump complete
--

